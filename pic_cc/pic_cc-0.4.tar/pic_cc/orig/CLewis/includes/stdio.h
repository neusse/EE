#define stdin 0
#define stdout 1
#define stderr 2
#define NULL 0
#define EOF (-1)
#define FILE char
