
/* some definitions for unsigned char compiler */

#define int char
#define unsigned


