
char a1,a2,a3;

main()
{
    a1 = 1;
    a2 = 2;
    a3 = a1+a2;
}
