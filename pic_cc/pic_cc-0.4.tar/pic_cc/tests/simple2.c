#define a 1
#define b 2
#define c 3
#define d 4
char ans1,ans2,ans3,ans4;


main()

{
	 ans1 = b * d;
	 ans2 = c - a;
	 ans3 = d / b;
	 ans4 = c + d;
 }
