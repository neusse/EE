/*Logomatic V02
9/11/07, compiled with changes to the FAT16 code to allow for really awful SD cards

/* *********************************************************
               Function declarations
  ********************************************************* */

#define IAP_LOCATION  0x7FFFFFF1
//#define FIQ_INTERRUPTS


void Initialize(void);
void feed(void);

void setup_uart0(int baud, char want_ints);
void setup_uart1(int baud, char want_ints);

void mode_0(void);
void mode_1(void);
void mode_2(void);
void mode_2_config(void);

void Log_init(void);
void test(void);

char getc(void);

void stat0_on (void);
void stat0_off (void);
void stat1_on (void);
void stat1_off (void);

void put_char(char);
void putc2(char);
char getc2(void);



//void T0isr(void)	__irq;
void IRQ_Routine (void)   __attribute__ ((interrupt("IRQ")));
static void UART0ISR(void) __attribute__ ((interrupt ("IRQ")));
static void UART0ISR_2(void) __attribute__ ((interrupt ("IRQ")));
static void UART1ISR(void) __attribute__ ((interrupt ("IRQ")));
static void MODE2ISR(void) __attribute__ ((interrupt ("IRQ")));

void FIQ_Routine (void)   __attribute__ ((interrupt("FIQ")));
void SWI_Routine (void)   __attribute__ ((interrupt("SWI")));
void UNDEF_Routine (void) __attribute__ ((interrupt("UNDEF")));

/**********************************************************
                  Header files
 **********************************************************/
#include "LPC21xx.h"
#include "fatLib.h"
#include "HALayer.h"
#include <__armlib.h>
//#include "SFE_io.h"
//#include "stdlib.h"
//#include "cmath.h"


/**********************************************************
                  Global Variables
 **********************************************************/
char port = 0;
char RX_array1[512];
char RX_array2[512];
char log_array1 = 0;
char log_array2 = 0;
char GPS_short[160];
char GPS_long[218];
char interval = 10;   //this is the alarm interval in minutes, default = 10
short RX_in = 0, RX_printed = 0;
float battery;
float temperature;
char get_frame = 0;


signed int stringSize;
signed char handle;
char stringBuf[100];
char title[10];

//Default settings=================================================================================
static char mode = 0;    //uart mode, 0 = uart auto, 1 = uart trigger, 2 = adc
static char asc = 'N';    //log in ascii mode
static int baud = 9600;   //baud = 9600
static int freq = 100;  //100Hz default for ADC operations
static char trig = '$';  //standard start of nmea sentences
static short frame = 100; //100 characters after trigger character IF it's in uart auto mode
static char ad1_5 = 'N';   //off
static char ad1_4 = 'N';   //off
static char ad1_3 = 'N';   //off
static char ad0_3 = 'N';   //off
static char ad0_2 = 'N';   //off
static char ad0_1 = 'N';   //off
static char ad1_2 = 'N';   //off
static char ad0_4 = 'N';   //off
static char ad1_7 = 'N';   //off
static char ad1_6 = 'N';   //off


//unsigned long command[5];
//unsigned long result[2];

//typedef void (*IAP)(unsigned long[],unsigned long[]);

//IAP iap_entry;

//struct flashcpy{
//  char data[256];//
//} __attribute__ ((aligned(256)));

//const flashcpy flashblock;
//flashcpy ramblock;

//typedef struct S { short f[3]; } __attribute__ ((aligned (8)));

/**********************************************************
                       MAIN
**********************************************************/
void __putchar(int ch)
{
  if (ch == '\n')
    put_char('\r');
  put_char(ch);
}

int	main (void)
{
    __ARMLIB_enableFIQ();

    //iap_entry=(IAP)IAP_LOCATION;

    int	j, k;
    
    int i;
    char q, f = 0;
    char temp;
    
    int y=0;
    char mon=0, d=0;
    char h=0, m1=0, m2 = 0, s=0;
    char a, b, c;
    
    Initialize();
    
    fat_initialize();   // Initialise the FAT library.

    setup_uart0(9600, 0);

    for (i = 0; i < 5; i++)
    {
        stat0_on();
        for (j = 0; j < 120000; j++);
        stat0_off();
        stat1_on();
        for (j = 0; j < 120000; j++);
        stat1_off();
    }

    Log_init();

    for (i = 0; i < 255; i++)
    {
        sprintf(title,"LOG%d.txt",i);
        handle = fat_openWrite(title);
        if (handle >= 0) break;
    }

    if (handle < 0) //If we can't open a file, lock up right here...===============================
    {
        while(1)
        {
            stat0_on();
            for (j = 0; j < 240000; j++);
            stat0_off();
            stat1_on();
            for (j = 0; j < 240000; j++);
            stat1_off();
        }
    }

    if (mode == 0) mode_0();
    else if (mode == 1) mode_1();
    else if (mode == 2) mode_2();

    //setup_uart0(baud, 1);
    //printf("UART0 setup...\r\n",0);
    
    //printf("\r\nGPS Logger\r\n",0);

    
    
    /*

    printf("Mode = %d\r\n", mode);
    printf("Baud = %d\r\n", baud);
    printf("Frequency = %d\r\n", freq);
    printf("Trigger = ", 0);
    put_char(trig);
    printf("\r\nExternal int = ", 0);
    put_char(ext_int);
    printf("\r\nFrame = %d\r\n", freq);
    printf("\r\nAD1.5 = ", 0);
    put_char(ad1_5);
    printf("\r\nAD1.4 = ", 0);
    put_char(ad1_4);
    printf("\r\nAD1.3 = ", 0);
    put_char(ad1_3);
    printf("\r\nAD0.3 = ", 0);
    put_char(ad0_3);
    printf("\r\nAD0.2 = ", 0);
    put_char(ad0_2);
    printf("\r\nAD0.1 = ", 0);
    put_char(ad0_1);
    printf("\r\nAD0.0 = ", 0);
    put_char(ad0_0);
    printf("\r\nAD0.4 = ", 0);
    put_char(ad0_4);
    printf("\r\nAD1.7 = ", 0);
    put_char(ad1_7);
    printf("\r\nAD1.6 = ", 0);
    put_char(ad1_6);

    */
    
    //setup_uart1(baud*100,0);

    //config_menu();
    
    //stat0_off();
    //stat1_off();
    //while(1);

    /*
    while (1)
    {
        stat0_on();
        for (j = 0; j < 360000; j++);
        stat0_off();
        stat1_on();
        for (j = 0; j < 360000; j++);
        stat1_off();
    }
    */

    //printf("UART1 setup...\r\n",0);
    
    /*
    handle = fat_openWrite("GPSlog.txt");
    if (handle >= 0)
    {
        strcpy(stringBuf, "Goodbye World!");
        stringSize = strlen(stringBuf);
        fat_write(handle,stringBuf, stringSize);
        fat_flush();    // Optional.
        fat_close(handle);
    }
    */

    //for (j = 0; j < 512; j++)
    //{
        //RX_array1[j] = 'X';
    //}

    //log_array1 = 1;


    
    
    
    

}



/**********************************************************
                      Initialize
**********************************************************/

#define PLOCK 0x400

void Initialize(void)
{
        short x;
	// Setting Multiplier and Divider values
  	PLLCFG=0x23;
  	feed();
  
	// Enabling the PLL */	
	PLLCON=0x1;
	feed();
  
	// Wait for the PLL to lock to set frequency
	while(!(PLLSTAT & PLOCK)) ;
  
	// Connect the PLL as the clock source
	PLLCON=0x3;
	feed();
  
	// Enabling MAM and setting number of clocks used for Flash memory fetch (4 cclks in this case)
	MAMCR=0x2;
	MAMTIM=0x4;
  
	// Setting peripheral Clock (pclk) to System Clock (cclk)
	VPBDIV=0x01;
	// Setting peripheral Clock (pclk) to System Clock (cclk)/2
	//VPBDIV=0x02;
	
        PINSEL0 = 0xCF351505;     // enable uart0, enable uart1, enable SPI0 but with SSEL as IO, AD1.2,1.3,1.4 1.5 active
	PINSEL1 = 0x15441801;   //AD0.1,0.2,0.3,0.4,1.6,1.7 active
        //PINSEL0 = 0x00051505;   //test code
        //PINSEL1 = 0x00000001;   //test code
	
	//IODIR0 |= 0x007E3C80;	// SSEL is an out, a bunch of LED's as well, mux control = out
        // Don't have to set the directin of the UART pins after they're configured with PINSEL0
                                        
	IODIR0 |= 0x00000884;   //

	//IOSET0  = 0x001E3C80;	// SSEL and the status LED's are low active, so set them high
	IOSET0 = 0x00000080;	//	

  	//set up the SPI port
  	S0SPCCR = 0x08;			// set up SPI clk to be pclk/8, this is the fastest we can go
	S0SPCR = 0x30;			//master, msb first, first clk edge, active high, no ints
	
	//T0TCR 		= 0x00000002;			//Reset counter and prescaler
	//T0MCR 		= 0x00000003;			//On match reset the counter and generate an interrupt
	//T0MR0		= 0x002D0000;			//Set the cycle time, 50mS
	//T0PR 		= 0x00000000;
	//T0MR1		= 0x00000000;			// Set duty cycle to zero
	//T0EMR  		= 0x00000042;			//On match clear MAT1
	//T0TCR 		= 0x00000001;			//enable timer
	
	//VICIntSelect = 0x00100000;			//BOD int
	
	//VICIntEnable = 0x00100000;			//Enable the interrupt
        //EXTWAKE = 0x80;


}


void feed(void)
{
  PLLFEED=0xAA;
  PLLFEED=0x55;
}






/*  Stubs for various interrupts (may be replaced later)  */
/*  ----------------------------------------------------  */

static void
UART0ISR(void)
{
      char temp;
      int j;

      //stat0_on();
      //for (j = 0; j < 5000000; j++);
      //stat0_off();
      
      
      if (RX_in < 512)
      {
          //stat0_on();
          RX_array1[RX_in] = U0RBR;
          RX_in++;

          if (RX_in == 512) log_array1 = 1;
      
      }

      else if (RX_in >= 512)
      {
          //stat1_on();
          RX_array2[RX_in - 512] = U0RBR;
          RX_in++;

          if (RX_in == 1024)
          {
              log_array2 = 1;
              RX_in = 0;
          }
      }

      //for (j = 0; j < 750000; j++);
      
      temp = U0IIR;	//have to read this to clear the int

      /* Update VIC priorities */
      VICVectAddr = 0;
      //stat0_off();
      //stat1_off();
}


static void
UART0ISR_2(void)
{
      char temp;
      int j;

      //stat0_on();
      //for (j = 0; j < 5000000; j++);
      //stat0_off();
      
      temp = U0RBR;

      if (temp == trig) get_frame = 1;

      if (get_frame == 1)
      {
          if (RX_in < frame)
          {
              //stat0_on();
              RX_array1[RX_in] = temp;
              RX_in++;
    
              if (RX_in == frame)
              {
                  RX_array1[RX_in] = 10;    //delimiters
                  RX_array1[RX_in + 1] = 13;
                  log_array1 = 1;
                  get_frame = 0;
              }
          
          }
    
          else if (RX_in >= frame)
          {
              //stat1_on();
              RX_array2[RX_in - frame] = temp;
              RX_in++;
    
              if (RX_in == 2*frame)
              {
                  RX_array2[RX_in - frame] = 10;    //delimiters
                  RX_array2[RX_in + 1 - frame] = 13;
                  log_array2 = 1;
                  get_frame = 0;
                  RX_in = 0;
              }
          }
      }
      //for (j = 0; j < 750000; j++);
      
      temp = U0IIR;	//have to read this to clear the int

      /* Update VIC priorities */
      VICVectAddr = 0;
      //stat0_off();
      //stat1_off();
}


static void
MODE2ISR(void)
{
    int temp, temp2;
    int j;
    short a;
    char q[50], index = 0, temp_buff[4], temp3;
    
    T0IR = 1;   //reset TMR0 interrupt
    
    //stat0_on();
    //for (j = 0; j < 15000; j++);
    //stat0_off();
    

    
        //Get AD1.5=======================================================================
        if (ad1_5 == 'Y')
        {
            AD1CR = 0x0020FF20;	//AD1.5
            AD1CR |= 0x01000000;//start conversion
            
            while ((temp & 0x80000000) == 0)
            {
                    temp = AD1DR;
            }
            
            
            temp &= 0x0000FFC0;
            temp2 = temp / 0x00000040;
            
            AD1CR = 0x00000000;

            if (asc == 'Y')
            {
                itoa(temp2, temp_buff, 10);
                if (temp_buff[0] >= 48)
                {
                    q[index] = temp_buff[0];
                    index++;
                }
                if (temp_buff[1] >= 48)
                {
                    q[index] = temp_buff[1];
                    index++;
                }
                if (temp_buff[2] >= 48)
                {
                    q[index] = temp_buff[2];
                    index++;
                }
                if (temp_buff[3] >= 48)
                {
                    q[index] = temp_buff[3];
                    index++;
                }
                
                q[index] = 9;
                index++;
                temp = 0;
                temp_buff[0] = 0;
                temp_buff[1] = 0;
                temp_buff[2] = 0;
                temp_buff[3] = 0;
            }
            
            else if (asc == 'N')
            {
                a = ((short)temp2 & 0xFF00) / 0x00000100;
                q[index] = (char)a;
        
                q[index+1] = (char)temp2 & 0xFF;
                index += 2;
                temp = 0;
            }
        
        }
    
        //Get AD1.4=======================================================================
        if (ad1_4 == 'Y')
        {
            AD1CR = 0x0020FF10;	//AD1.4
            AD1CR |= 0x01000000;//start conversion
            
            while ((temp & 0x80000000) == 0)
            {
                    temp = AD1DR;
            }
            
            
            temp &= 0x0000FFC0;
            temp2 = temp / 0x00000040;
            
            AD1CR = 0x00000000;
            
            if (asc == 'Y')
            {
                itoa(temp2, temp_buff, 10);
                if (temp_buff[0] >= 48)
                {
                    q[index] = temp_buff[0];
                    index++;
                }
                if (temp_buff[1] >= 48)
                {
                    q[index] = temp_buff[1];
                    index++;
                }
                if (temp_buff[2] >= 48)
                {
                    q[index] = temp_buff[2];
                    index++;
                }
                if (temp_buff[3] >= 48)
                {
                    q[index] = temp_buff[3];
                    index++;
                }

                q[index] = 9;
                index++;
                temp = 0;
                temp_buff[0] = 0;
                temp_buff[1] = 0;
                temp_buff[2] = 0;
                temp_buff[3] = 0;
            }
            
            else if (asc == 'N')
            {
                a = ((short)temp2 & 0xFF00) / 0x00000100;
                q[index] = (char)a;
        
                q[index+1] = (char)temp2 & 0xFF;
                index += 2;
                temp = 0;
            }
        }
        
        //Get AD1.3=======================================================================
        if (ad1_3 == 'Y')
        {
            AD1CR = 0x0020FF08;	//AD1.3
            AD1CR |= 0x01000000;//start conversion
            
            while ((temp & 0x80000000) == 0)
            {
                    temp = AD1DR;
            }
            
            
            temp &= 0x0000FFC0;
            temp2 = temp / 0x00000040;
            
            AD1CR = 0x00000000;
            
            if (asc == 'Y')
            {
                itoa(temp2, temp_buff, 10);
                if (temp_buff[0] >= 48)
                {
                    q[index] = temp_buff[0];
                    index++;
                }
                if (temp_buff[1] >= 48)
                {
                    q[index] = temp_buff[1];
                    index++;
                }
                if (temp_buff[2] >= 48)
                {
                    q[index] = temp_buff[2];
                    index++;
                }
                if (temp_buff[3] >= 48)
                {
                    q[index] = temp_buff[3];
                    index++;
                }

                q[index] = 9;
                index++;
                temp = 0;
                temp_buff[0] = 0;
                temp_buff[1] = 0;
                temp_buff[2] = 0;
                temp_buff[3] = 0;
            }
            
            else if (asc == 'N')
            {
                a = ((short)temp2 & 0xFF00) / 0x00000100;
                q[index] = (char)a;
        
                q[index+1] = (char)temp2 & 0xFF;
                index += 2;
                temp = 0;
            }
        }
        
        //Get AD0.3=======================================================================
        if (ad0_3 == 'Y')
        {
            AD0CR = 0x0020FF08;	//AD0.3
            AD0CR |= 0x01000000;//start conversion
            
            while ((temp & 0x80000000) == 0)
            {
                    temp = AD0DR;
            }
            
            
            temp &= 0x0000FFC0;
            temp2 = temp / 0x00000040;
            
            AD0CR = 0x00000000;
            
            if (asc == 'Y')
            {
                itoa(temp2, temp_buff, 10);
                if (temp_buff[0] >= 48)
                {
                    q[index] = temp_buff[0];
                    index++;
                }
                if (temp_buff[1] >= 48)
                {
                    q[index] = temp_buff[1];
                    index++;
                }
                if (temp_buff[2] >= 48)
                {
                    q[index] = temp_buff[2];
                    index++;
                }
                if (temp_buff[3] >= 48)
                {
                    q[index] = temp_buff[3];
                    index++;
                }

                q[index] = 9;
                index++;
                temp = 0;
                temp_buff[0] = 0;
                temp_buff[1] = 0;
                temp_buff[2] = 0;
                temp_buff[3] = 0;
            }
            
            else if (asc == 'N')
            {
                a = ((short)temp2 & 0xFF00) / 0x00000100;
                q[index] = (char)a;
        
                q[index+1] = (char)temp2 & 0xFF;
                index += 2;
                temp = 0;
            }
        }
        
        
        //Get AD0.2=======================================================================
        if (ad0_2 == 'Y')
        {
            AD0CR = 0x0020FF04;	//AD0.2
            AD0CR |= 0x01000000;//start conversion
            
            while ((temp & 0x80000000) == 0)
            {
                    temp = AD0DR;
            }
            
            temp &= 0x0000FFC0;
            temp2 = temp / 0x00000040;
            
            AD0CR = 0x00000000;
            
            if (asc == 'Y')
            {
                itoa(temp2, temp_buff, 10);
                if (temp_buff[0] >= 48)
                {
                    q[index] = temp_buff[0];
                    index++;
                }
                if (temp_buff[1] >= 48)
                {
                    q[index] = temp_buff[1];
                    index++;
                }
                if (temp_buff[2] >= 48)
                {
                    q[index] = temp_buff[2];
                    index++;
                }
                if (temp_buff[3] >= 48)
                {
                    q[index] = temp_buff[3];
                    index++;
                }

                q[index] = 9;
                index++;
                temp = 0;
                temp_buff[0] = 0;
                temp_buff[1] = 0;
                temp_buff[2] = 0;
                temp_buff[3] = 0;
            }
            
            else if (asc == 'N')
            {
                a = ((short)temp2 & 0xFF00) / 0x00000100;
                q[index] = (char)a;
        
                q[index+1] = (char)temp2 & 0xFF;
                index += 2;
                temp = 0;
            }
        }
    
        
        //Get AD0.1=======================================================================
        if (ad0_1 == 'Y')
        {
            AD0CR = 0x0020FF02;	//AD0.1
            AD0CR |= 0x01000000;//start conversion
            
            while ((temp & 0x80000000) == 0)
            {
                    temp = AD0DR;
            }
            
            temp &= 0x0000FFC0;
            temp2 = temp / 0x00000040;
            
            AD0CR = 0x00000000;
            
            if (asc == 'Y')
            {
                itoa(temp2, temp_buff, 10);
                if (temp_buff[0] >= 48)
                {
                    q[index] = temp_buff[0];
                    index++;
                }
                if (temp_buff[1] >= 48)
                {
                    q[index] = temp_buff[1];
                    index++;
                }
                if (temp_buff[2] >= 48)
                {
                    q[index] = temp_buff[2];
                    index++;
                }
                if (temp_buff[3] >= 48)
                {
                    q[index] = temp_buff[3];
                    index++;
                }

                q[index] = 9;
                index++;
                temp = 0;
                temp_buff[0] = 0;
                temp_buff[1] = 0;
                temp_buff[2] = 0;
                temp_buff[3] = 0;
            }
            
            else if (asc == 'N')
            {
                a = ((short)temp2 & 0xFF00) / 0x00000100;
                q[index] = (char)a;
        
                q[index+1] = (char)temp2 & 0xFF;
                index += 2;
                temp = 0;
            }
        }
    
        
        //Get AD1.2========================================================================
        if (ad1_2 == 'Y')
        {
            AD1CR = 0x0020FF04;	//AD0.0, P0.27
            AD1CR |= 0x01000000;	//start conversion
            
            while ((temp & 0x80000000) == 0)
            {
                    temp = AD1DR;
            }
            
            temp &= 0x0000FFC0;
            temp2 = temp / 0x00000040;
            
            AD1CR = 0x00000000;
            
            if (asc == 'Y')
            {
                itoa(temp2, temp_buff, 10);
                if (temp_buff[0] >= 48)
                {
                    q[index] = temp_buff[0];
                    index++;
                }
                if (temp_buff[1] >= 48)
                {
                    q[index] = temp_buff[1];
                    index++;
                }
                if (temp_buff[2] >= 48)
                {
                    q[index] = temp_buff[2];
                    index++;
                }
                if (temp_buff[3] >= 48)
                {
                    q[index] = temp_buff[3];
                    index++;
                }

                q[index] = 9;
                index++;
                temp = 0;
                temp_buff[0] = 0;
                temp_buff[1] = 0;
                temp_buff[2] = 0;
                temp_buff[3] = 0;
            }
            
            else if (asc == 'N')
            {
                a = ((short)temp2 & 0xFF00) / 0x00000100;
                q[index] = (char)a;
        
                q[index+1] = (char)temp2 & 0xFF;
                index += 2;
                temp = 0;
            }
        }
        
        
        //Get AD0.4=======================================================================
        if (ad0_4 == 'Y')
        {
            AD0CR = 0x0020FF10;	//AD0.4
            AD0CR |= 0x01000000;//start conversion
            
            while ((temp & 0x80000000) == 0)
            {
                    temp = AD0DR;
            }
            
            temp &= 0x0000FFC0;
            temp2 = temp / 0x00000040;
            
            AD0CR = 0x00000000;
            
            if (asc == 'Y')
            {
                itoa(temp2, temp_buff, 10);
                if (temp_buff[0] >= 48)
                {
                    q[index] = temp_buff[0];
                    index++;
                }
                if (temp_buff[1] >= 48)
                {
                    q[index] = temp_buff[1];
                    index++;
                }
                if (temp_buff[2] >= 48)
                {
                    q[index] = temp_buff[2];
                    index++;
                }
                if (temp_buff[3] >= 48)
                {
                    q[index] = temp_buff[3];
                    index++;
                }

                q[index] = 9;
                index++;
                temp = 0;
                temp_buff[0] = 0;
                temp_buff[1] = 0;
                temp_buff[2] = 0;
                temp_buff[3] = 0;
            }
            
            else if (asc == 'N')
            {
                a = ((short)temp2 & 0xFF00) / 0x00000100;
                q[index] = (char)a;
        
                q[index+1] = (char)temp2 & 0xFF;
                index += 2;
                temp = 0;
            }
        }
        
        //Get AD1.7=======================================================================
        if (ad1_7 == 'Y')
        {
            AD1CR = 0x0020FF80;	//AD1.7
            AD1CR |= 0x01000000;//start conversion
            
            while ((temp & 0x80000000) == 0)
            {
                    temp = AD1DR;
            }
            
            temp &= 0x0000FFC0;
            temp2 = temp / 0x00000040;
            
            AD1CR = 0x00000000;
            
            if (asc == 'Y')
            {
                itoa(temp2, temp_buff, 10);
                if (temp_buff[0] >= 48)
                {
                    q[index] = temp_buff[0];
                    index++;
                }
                if (temp_buff[1] >= 48)
                {
                    q[index] = temp_buff[1];
                    index++;
                }
                if (temp_buff[2] >= 48)
                {
                    q[index] = temp_buff[2];
                    index++;
                }
                if (temp_buff[3] >= 48)
                {
                    q[index] = temp_buff[3];
                    index++;
                }

                q[index] = 9;
                index++;
                temp = 0;
                temp_buff[0] = 0;
                temp_buff[1] = 0;
                temp_buff[2] = 0;
                temp_buff[3] = 0;
            }
            
            else if (asc == 'N')
            {
                a = ((short)temp2 & 0xFF00) / 0x00000100;
                q[index] = (char)a;
        
                q[index+1] = (char)temp2 & 0xFF;
                index += 2;
                temp = 0;
            }
        }
    
        
        //Get AD1.6=======================================================================
        if (ad1_6 == 'Y')
        {
            AD1CR = 0x0020FF40;	//AD1.6
            AD1CR |= 0x01000000;//start conversion
            
            while ((temp & 0x80000000) == 0)
            {
                    temp = AD1DR;
            }
            
            temp &= 0x0000FFC0;
            temp2 = temp / 0x00000040;
            
            AD1CR = 0x00000000;
            
            if (asc == 'Y')
            {
                itoa(temp2, temp_buff, 10);
                if (temp_buff[0] >= 48)
                {
                    q[index] = temp_buff[0];
                    index++;
                }
                if (temp_buff[1] >= 48)
                {
                    q[index] = temp_buff[1];
                    index++;
                }
                if (temp_buff[2] >= 48)
                {
                    q[index] = temp_buff[2];
                    index++;
                }
                if (temp_buff[3] >= 48)
                {
                    q[index] = temp_buff[3];
                    index++;
                }

                temp = 0;
                temp_buff[0] = 0;
                temp_buff[1] = 0;
                temp_buff[2] = 0;
                temp_buff[3] = 0;
            }
            
            else if (asc == 'N')
            {
                a = ((short)temp2 & 0xFF00) / 0x00000100;
                q[index] = (char)a;
        
                q[index+1] = (char)temp2 & 0xFF;
                index += 2;
                temp = 0;
            }
        }
        
        for (j = 0; j < index; j++) //Data=========================================================
        {
            if (RX_in < 512)
            {
              //stat0_on();
              RX_array1[RX_in] = q[j];
              RX_in++;
            
              if (RX_in == 512) log_array1 = 1;
            
            }
            
            else if (RX_in >= 512)
            {
              //stat1_on();
              RX_array2[RX_in - 512] = q[j];
              RX_in++;
            
              if (RX_in == 1024)
              {
                  log_array2 = 1;
                  RX_in = 0;
              }
            }
        }
        

        //temp3 = 10;

        //for (j = 0; j < 2; j++) //Delimiters========================================================
        //{
            if (RX_in < 512)
            {
              //stat0_on();
              if (asc == 'N') RX_array1[RX_in] = '$';
              else if (asc == 'Y') RX_array1[RX_in] = 13;
              RX_in++;
            
              if (RX_in == 512) log_array1 = 1;
            
            }
            
            else if (RX_in >= 512)
            {
              //stat1_on();
              if (asc == 'N') RX_array2[RX_in - 512] = '$';
              else if (asc == 'Y') RX_array2[RX_in - 512] = 13;//changed 9/21/07
              RX_in++;
            
              if (RX_in == 1024)
              {
                  log_array2 = 1;
                  RX_in = 0;
              }
            }


            if (RX_in < 512)
            {
              //stat0_on();
              if (asc == 'N') RX_array1[RX_in] = '$';
              else if (asc == 'Y') RX_array1[RX_in] = 10;
              RX_in++;
            
              if (RX_in == 512) log_array1 = 1;
            
            }
            
            else if (RX_in >= 512)
            {
              //stat1_on();
              if (asc == 'N') RX_array2[RX_in - 512] = '$';
              else if (asc == 'Y') RX_array2[RX_in - 512] = 10;//changed 9/21/07
              RX_in++;
            
              if (RX_in == 1024)
              {
                  log_array2 = 1;
                  RX_in = 0;
              }
            }



            //temp3 = 13;
        //}
        

        //for (j = 0; j < 750000; j++);
  /* Update VIC priorities */
    VICVectAddr = 0;
    //stat0_off();
    //stat1_off();
}
    
static void
UART1ISR(void)
{
      char temp;
      int j;

      stat0_on();
      for (j = 0; j < 750000; j++);
      stat0_off();
      
      temp = U1RBR;

      /*
      if (RX_in < 512)
      {
          stat0_on();
          RX_array1[RX_in] = U1RBR;
          RX_in++;

          if (RX_in == 512) log_array1 = 1;
      
      }

      else if (RX_in >= 512)
      {
          stat1_on();
          RX_array2[RX_in] = U1RBR;
          RX_in++;

          if (RX_in == 1024)
          {
              log_array2 = 1;
              RX_in = 0;
          }
      }
      */

          

      //for (j = 0; j < 750000; j++);
      
      temp = U1IIR;	//have to read this to clear the int

      /* Update VIC priorities */
      VICVectAddr = 0;
      //stat0_off();
      //stat1_off();
}



void FIQ_Routine (void)
{
	char a;
	int j;
        
        stat0_on();
        for (j = 0; j < 5000000; j++);
        stat0_off();
        a = U0RBR;

        a = U0IIR;	//have to read this to clear the int
        //ILR = 3;
        
}


void SWI_Routine (void)  {
	while (1) ;	
}


void UNDEF_Routine (void) {
	
	stat0_on();
	//while (1) ;	
}

//Sends nate to the Transmit Register
void put_char(char c)
{
    if (port == 0)
    {
        while((U0LSR & 0x20) == 0);
        U0THR = c;
    }
    else if (port == 1)
    {
        while((U1LSR & 0x20) == 0);
        U1THR = c;
    }
}


//specific to UART0
char getc(void)
{
    while((U0LSR & 0x01) == 0);
    return (U0RBR);
}
   
char getc2(void)
{
    while((U1LSR & 0x01) == 0);
    return (U1RBR);
}


void putc2(char c)
{
    while((U1LSR & 0x20) == 0);
    U1THR = c;
}

void stat0_on (void)
{
	IOCLR0 = 0x00000004;

}

void stat0_off (void)
{
	IOSET0 = 0x00000004;
	
}

void stat1_on (void)
{
	IOCLR0 = 0x00000800;

}

void stat1_off (void)
{
	IOSET0 = 0x00000800;

}



void setup_uart0(int baud, char want_ints)
{
	//set up uart0 
	U0LCR 	= 0x83;			// 8 bits, no Parity, 1 Stop bit, DLAB = 1
	
	if (baud == 1200)
	{
		U0DLM   = 0x0C;		  	//
  		U0DLL 	= 0x00;        	// 4800 Baud Rate @ 58982400 VPB Clock
	}
	
	if (baud == 2400)
	{
		U0DLM   = 0x06;		  	//
  		U0DLL 	= 0x00;        	// 4800 Baud Rate @ 58982400 VPB Clock
	}
		
	if (baud == 4800)
	{
		U0DLM   = 0x03;		  	//
  		U0DLL 	= 0x00;        	// 4800 Baud Rate @ 58982400 VPB Clock
	}
	
	else if (baud == 9600)
	{
	 	U0DLM   = 0x01;		  	//
  		U0DLL 	= 0x80;        	// 9600 Baud Rate @ 58982400 VPB Clock
	}
	
	else if (baud == 19200)
	{
	 	U0DLM   = 0x00;		  	//
  		U0DLL 	= 0xC0;        	// 19200 Baud Rate @ 58982400 VPB Clock
	}
	
	else if (baud == 38400)
	{
	 	U0DLM   = 0x00;		  	//
  		U0DLL 	= 0x60;        	// 38400 Baud Rate @ 58982400 VPB Clock
	}

        else if (baud == 57600)
	{
	 	U0DLM   = 0x00;		  	//
  		U0DLL 	= 0x40;        	// 57600 Baud Rate @ 58982400 VPB Clock
	}

        else if (baud == 115200)
	{
	 	U0DLM   = 0x00;		  	//
  		U0DLL 	= 0x20;        	// 115200 Baud Rate @ 58982400 VPB Clock
	}
	                    
  	U0FCR	= 0x01;			// Not sure this is necessary, but the manual sez it is
	U0LCR 	= 0x03;        	// DLAB = 0

        if (want_ints == 1)
	{
            //__ARMLIB_enableFIQ();
            __ARMLIB_enableIRQ();

            //stat1_on();
            /* UART0 interrupt is an IRQ interrupt */
            //VICIntSelect |= 0x00000040;
            VICIntSelect &= ~0x00000040;
            /* Enable UART interrupt */
            VICIntEnable |= 0x00000040;
            /* Use slot 1 for UART0 interrupt */
            VICVectCntl1 = 0x26;
            /* Set the address of ISR for slot 1 */
            VICVectAddr1 = (unsigned int)UART0ISR;

            

            //VICIntSelect |= 0x00000080;		//bit 7 is for UART1, sets to FIQ (not IRQ)
            //VICIntEnable |= 0x00000080;	//enables UART1 interupt
            U0IER = 0x01;					//enable RX data available interupt, DLAB must be 0 to write
		
	}

        else if (want_ints == 2)
        {
            //__ARMLIB_enableFIQ();
            __ARMLIB_enableIRQ();

            //stat1_on();
            /* UART0 interrupt is an IRQ interrupt */
            //VICIntSelect |= 0x00000040;
            VICIntSelect &= ~0x00000040;
            /* Enable UART interrupt */
            VICIntEnable |= 0x00000040;
            /* Use slot 1 for UART0 interrupt */
            VICVectCntl2 = 0x26;
            /* Set the address of ISR for slot 1 */
            VICVectAddr2 = (unsigned int)UART0ISR_2;

            

            //VICIntSelect |= 0x00000080;		//bit 7 is for UART1, sets to FIQ (not IRQ)
            //VICIntEnable |= 0x00000080;	//enables UART1 interupt
            U0IER = 0x01;					//enable RX data available interupt, DLAB must be 0 to write
		
	}
	
	else if (want_ints == 0)
	{
		VICIntEnClr = 0x00000040;	//disables UART0 interupt
		U0IER = 0x00;					//disable RX data available interupt, DLAB must be 0 to write
	}
	
      
}


void setup_uart1(int baud, char want_ints)
{
        char q;

	//set up uart1
	U1LCR 	= 0x83;			// 8 bits, no Parity, 1 Stop bit, DLAB = 1
	
	if (baud == 1200)
	{
		U1DLM   = 0x0C;		  	//
  		U1DLL 	= 0x00;        	// 4800 Baud Rate @ 58982400 VPB Clock
	}
	
	if (baud == 2400)
	{
		U1DLM   = 0x06;		  	//
  		U1DLL 	= 0x00;        	// 4800 Baud Rate @ 58982400 VPB Clock
	}
	
	if (baud == 4800)
	{
		U1DLM   = 0x03;		  	//
  		U1DLL 	= 0x00;        	// 4800 Baud Rate @ 58982400 VPB Clock
	}
	
	else if (baud == 9600)
	{
	 	U1DLM   = 0x01;		  	//
  		U1DLL 	= 0x80;        	// 9600 Baud Rate @ 58982400 VPB Clock
	}
	
	else if (baud == 19200)
	{
	 	U1DLM   = 0x00;		  	//
  		U1DLL 	= 0xC0;        	// 19200 Baud Rate @ 58982400 VPB Clock
	}
	
	else if (baud == 38400)
	{
	 	U1DLM   = 0x00;		  	//
  		U1DLL 	= 0x60;        	// 38400 Baud Rate @ 58982400 VPB Clock
	}
	//U1IER = 0x01;					//enable RX data available interupt, DLAB must be 0 to write               
  	U1FCR	= 0x03;			// Not sure this is necessary, but the manual sez it is
  	
	U1LCR 	= 0x03;        	// DLAB = 0
	
	q = U1RBR;


	if (want_ints == 1)
	{
            //stat1_on();
            /* UART1 interrupt is an IRQ interrupt */
            VICIntSelect &= ~0x80;
            /* Enable UART interrupt */
            VICIntEnable = 0x80;
            /* Use slot 0 for UART1 interrupt */
            VICVectCntl0 = 0x27;
            /* Set the address of ISR for slot 0 */
            VICVectAddr0 = (unsigned int)UART1ISR;

            __ARMLIB_enableIRQ();

            //VICIntSelect |= 0x00000080;		//bit 7 is for UART1, sets to FIQ (not IRQ)
            //VICIntEnable |= 0x00000080;	//enables UART1 interupt
            U1IER = 0x01;					//enable RX data available interupt, DLAB must be 0 to write
		
	}
	
	else if (want_ints == 0)
	{
		VICIntEnClr = 0x00000080;	//disables UART1 interupt
		U1IER = 0x00;					//disable RX data available interupt, DLAB must be 0 to write
	}
	

}



void Log_init(void)
{
    int j, x, mark = 0, index = 0;
    char temp, temp2 = 0;
    signed int stringSize;
    signed char handle;
    char stringBuf[256], safety;

    handle = fat_openRead("LOGcon.txt");
    if (handle >= 0)
    {
        stringSize = fat_read(handle, stringBuf, 512);
        stringBuf[stringSize] = '\0';
        //printf(stringBuf);
        fat_close(handle);
    }

    else
    {
        handle = fat_openWrite("LOGcon.txt");
        if (handle >= 0)
        {
            strcpy(stringBuf, "MODE = 0\r\nASCII = N\r\nBaud = 4\r\nFrequency = 100\r\nTrigger Character = $\r\nText Frame = 100\r\nAD1.5 = N\r\nAD1.4 = N\r\nAD1.3 = N\r\nAD0.3 = N\r\nAD0.2 = N\r\nAD0.1 = N\r\nAD1.2 = N\r\nAD0.4 = N\r\nAD1.7 = N\r\nAD1.6 = N\r\nSafty On = Y\r\n");
            stringSize = strlen(stringBuf);
            fat_write(handle,stringBuf, stringSize);
            
            /*
            strcpy(stringBuf, "LOG = ALL\r\n");
            stringSize = strlen(stringBuf);
            fat_write(handle,stringBuf, stringSize);
            */

            fat_flush();    // Optional.
            fat_close(handle);
        }

        else if (handle < 0)
        {
            while(1)    //in case there's no card or it's full...
            {
                stat0_on();
                for (j = 0; j < 500000; j++);
                stat0_off();
                stat1_on();
                for (j = 0; j < 500000; j++);
                stat1_off();
            }
        }
    }
    
    
    for (x = 0; x < stringSize; x++)
    {
        temp = stringBuf[x];
        if (temp == 10)
        {
            mark = x;
            index++;

            if (index == 1)
            {
                mode = stringBuf[mark - 2] - 48; //0 = auto uart, 1 = trigger uart, 2 = adc
            }

            else if (index == 2)
            {
                asc = stringBuf[mark - 2];    //default is 'N'
            }
        
            else if (index == 3)
            {
                if (stringBuf[mark - 2] == '1') baud = 1200;
                else if (stringBuf[mark - 2] == '2') baud = 2400;
                else if (stringBuf[mark - 2] == '3') baud = 4800;
                else if (stringBuf[mark - 2] == '4') baud = 9600;
                else if (stringBuf[mark - 2] == '5') baud = 19200;
                else if (stringBuf[mark - 2] == '6') baud = 38400;
                else if (stringBuf[mark - 2] == '7') baud = 57600;
                else if (stringBuf[mark - 2] == '8') baud = 115200;
                
            }
            
            else if (index == 4)
            {
                freq = (stringBuf[mark - 2] - 48) + (stringBuf[mark - 3] - 48) * 10;
                if ((stringBuf[mark - 4] >= 48) && (stringBuf[mark - 4] < 58))
                {
                    freq += (stringBuf[mark - 4] - 48) * 100;
                    if ((stringBuf[mark - 5] >= 48) && (stringBuf[mark - 5] < 58)) freq += (stringBuf[mark - 5] - 48) * 1000;
                }
            }
    
            else if (index == 5)
            {
                trig = stringBuf[mark - 2]; //default is $
                
            }
    
            else if (index == 6)
            {
                frame = (stringBuf[mark - 2] - 48) + (stringBuf[mark - 3] - 48) * 10 + (stringBuf[mark - 4] - 48) * 100;  
                if (frame > 510) frame = 510;//Up to 510 characters
            }

            else if (index == 7)
            {
                ad1_5 = stringBuf[mark - 2]; //default is 'N'
                if (ad1_5 == 'Y') temp2++;
            }

            else if (index == 8)
            {
                ad1_4 = stringBuf[mark - 2]; //default is 'N'
                if (ad1_4 == 'Y') temp2++;
            }

            else if (index == 9)
            {
                ad1_3 = stringBuf[mark - 2]; //default is 'N'
                if (ad1_3 == 'Y') temp2++;
            }

            else if (index == 10)
            {
                ad0_3 = stringBuf[mark - 2]; //default is 'N'
                if (ad0_3 == 'Y') temp2++;
            }

            else if (index == 11)
            {
                ad0_2 = stringBuf[mark - 2]; //default is 'N'
                if (ad0_2 == 'Y') temp2++;
            }

            else if (index == 12)
            {
                ad0_1 = stringBuf[mark - 2]; //default is 'N'
                if (ad0_1 == 'Y') temp2++;
            }

            else if (index == 13)
            {
                ad1_2 = stringBuf[mark - 2]; //default is 'N'
                if (ad1_2 == 'Y') temp2++;
            }

            else if (index == 14)
            {
                ad0_4 = stringBuf[mark - 2]; //default is 'N'
                if (ad0_4 == 'Y') temp2++;
            }

            else if (index == 15)
            {
                ad1_7 = stringBuf[mark - 2]; //default is 'N'
                if (ad1_7 == 'Y') temp2++;
            }

            else if (index == 16)
            {
                ad1_6 = stringBuf[mark - 2]; //default is 'N'
                if (ad1_6 == 'Y') temp2++;
            }

            else if (index == 17)
            {
                safety = stringBuf[mark - 2]; //default is 'Y'
                
            }
        }

    }

    if (safety == 'Y')    //make sure the frequency is within limits for ADC mode if safety is on
    {
        if ((temp2 == 10) && (freq > 150)) freq = 150;
        else if ((temp2 == 9) && (freq > 166)) freq = 166;
        else if ((temp2 == 8) && (freq > 187)) freq = 187;
        else if ((temp2 == 7) && (freq > 214)) freq = 214;
        else if ((temp2 == 6) && (freq > 250)) freq = 250;
        else if ((temp2 == 5) && (freq > 300)) freq = 300;
        else if ((temp2 == 4) && (freq > 375)) freq = 375;
        else if ((temp2 == 3) && (freq > 500)) freq = 500;
        else if ((temp2 == 2) && (freq > 750)) freq = 750;
        else if ((temp2 == 1) && (freq > 1500)) freq = 1500;
        else if (temp2 == 0) freq = 100;

        
    }

    if (safety == 'T') test();

    //printf("%d\r\n",freq);

}



//Auto UART mode =============================================================================================
void mode_0(void)
{
    setup_uart0(baud, 1);
    stringSize = 512;
    int j;

    while(1)
    {
        if (log_array1 == 1)
        {
            stat0_on();

            if (fat_write(handle,RX_array1, stringSize) < 0) //stop if we can't write
            {
                while(1)
                {
                    stat0_on();
                    for (j = 0; j < 500000; j++);
                    stat0_off();
                    stat1_on();
                    for (j = 0; j < 500000; j++);
                    stat1_off();
                }
            }

            fat_flush();
            stat0_off();
            log_array1 = 0;
        }

        //for (j = 0; j < 5000000; j++);

        if (log_array2 == 1)
        {
            stat1_on();

            if (fat_write(handle,RX_array2, stringSize) < 0) //stop if we can't write
            {
                while(1)
                {
                    stat0_on();
                    for (j = 0; j < 500000; j++);
                    stat0_off();
                    stat1_on();
                    for (j = 0; j < 500000; j++);
                    stat1_off();
                }
            }

            fat_flush();
            stat1_off();
            log_array2 = 0;
        }
        
        //if the button has been pushed, log the rest of the file and quit
        if ((IOPIN0 & 0x00000008) == 0)    
        {
            VICIntEnClr = 0xFFFFFFFF;  //clear all interrupts

            if (RX_in < 512)
            {
                fat_write(handle,RX_array1, RX_in);
                fat_flush();
            }
    
            else if (RX_in >= 512)
            {
                fat_write(handle,RX_array2, RX_in - 512);
                fat_flush();
            }
    
            while(1)
            {
                stat0_on();
                for (j = 0; j < 500000; j++);
                stat0_off();
                stat1_on();
                for (j = 0; j < 500000; j++);
                stat1_off();
            }
        }
    }


}


//Triggered UART mode ========================================================================================
void mode_1(void)
{
    setup_uart0(baud, 2);
    stringSize = frame+2;
    int j;

    while(1)
    {
        if (log_array1 == 1)
        {
            stat0_on();

            if (fat_write(handle,RX_array1, stringSize) < 0)
            {
                while(1)
                {
                    stat0_on();
                    for (j = 0; j < 500000; j++);
                    stat0_off();
                    stat1_on();
                    for (j = 0; j < 500000; j++);
                    stat1_off();
                }
            }

            fat_flush();
            stat0_off();
            log_array1 = 0;
        }

        //for (j = 0; j < 5000000; j++);

        if (log_array2 == 1)
        {
            stat1_on();
            
            if (fat_write(handle,RX_array2, stringSize) < 0)
            {
                while(1)
                {
                    stat0_on();
                    for (j = 0; j < 500000; j++);
                    stat0_off();
                    stat1_on();
                    for (j = 0; j < 500000; j++);
                    stat1_off();
                }
            }

            fat_flush();
            stat1_off();
            log_array2 = 0;
        }

        if ((IOPIN0 & 0x00000008) == 0)    //if the button has been pushed, log the rest of the file and quit
        {
            VICIntEnClr = 0xFFFFFFFF;  //clear all interrupts

            if (RX_in < 512)
            {
                fat_write(handle,RX_array1, RX_in);
                fat_flush();
            }
    
            else if (RX_in >= 512)
            {
                fat_write(handle,RX_array2, RX_in - 512);
                fat_flush();
            }
    
            while(1)
            {
                stat0_on();
                for (j = 0; j < 500000; j++);
                stat0_off();
                stat1_on();
                for (j = 0; j < 500000; j++);
                stat1_off();
            }
        }
    }

}


//ADC mode ==================================================================================================
void mode_2(void)
{
    int j;
    mode_2_config();

    while(1)
    {
        if (log_array1 == 1)
        {
            stat0_on();

            if (fat_write(handle,RX_array1, 512) < 0)
            {
                while(1)
                {
                    stat0_on();
                    for (j = 0; j < 500000; j++);
                    stat0_off();
                    stat1_on();
                    for (j = 0; j < 500000; j++);
                    stat1_off();
                }
            }

            fat_flush();
            stat0_off();
            log_array1 = 0;
        }

        //for (j = 0; j < 5000000; j++);

        if (log_array2 == 1)
        {
            stat1_on();

            if (fat_write(handle,RX_array2, 512) < 0)
            {
                while(1)
                {
                    stat0_on();
                    for (j = 0; j < 500000; j++);
                    stat0_off();
                    stat1_on();
                    for (j = 0; j < 500000; j++);
                    stat1_off();
                }
            }

            fat_flush();
            stat1_off();
            log_array2 = 0;
        }

        if ((IOPIN0 & 0x00000008) == 0)    //if the button has been pushed, log the rest of the file and quit
        {
            VICIntEnClr = 0xFFFFFFFF;  //clear all interrupts

            if (RX_in < 512)
            {
                fat_write(handle,RX_array1, RX_in);
                fat_flush();
            }
    
            else if (RX_in >= 512)
            {
                fat_write(handle,RX_array2, RX_in - 512);
                fat_flush();
            }
    
            while(1)
            {
                stat0_on();
                for (j = 0; j < 500000; j++);
                stat0_off();
                stat1_on();
                for (j = 0; j < 500000; j++);
                stat1_off();
            }
        }

    }

}

void mode_2_config(void)
{
    __ARMLIB_enableIRQ();

    //stat1_on();
    /* Timer0 interrupt is an IRQ interrupt */
    VICIntSelect &= ~0x00000010;
    /* Enable Timer0 interrupt */
    VICIntEnable |= 0x00000010;
    /* Use slot 2 for UART0 interrupt */
    VICVectCntl2 = 0x24;
    /* Set the address of ISR for slot 1 */
    VICVectAddr2 = (unsigned int)MODE2ISR;

    T0TCR = 0x00000002;			//Reset counter and prescaler
    T0MCR = 0x00000003;			//On match reset the counter and generate an interrupt
    //T0MR0 = 589824;			//Set for 100Hz
    //T0MR0 = 1179648;			//Set for 50Hz
    T0MR0 = 58982400 / freq;

    T0PR = 0x00000000;
	
	//T0EMR  		= 0x00000042;			//On match clear MAT1
    T0TCR = 0x00000001;			//enable timer

}

void test(void)
{
    int temp, temp2;
    int j;
    char a;

    printf("Logomatic Test Code:\r\n",0);
    printf("Hit any key to test ADC lines, hit the stop button to terminate the test.\r\n\n",0);

    a = getc();
    
    
    while ((IOPIN0 & 0x00000008) == 0x00000008)
    {
        //Get AD1.5=======================================================================
        AD1CR = 0x0020FF20;	//AD1.5
        AD1CR |= 0x01000000;//start conversion
        
        while ((temp & 0x80000000) == 0)
        {
                temp = AD1DR;
        }
        
        
        temp &= 0x0000FFC0;
        temp2 = temp / 0x00000040;
        
        AD1CR = 0x00000000;
        
        printf("%d",temp2);
        put_char(9);
                
        
        //Get AD1.4=======================================================================
        AD1CR = 0x0020FF10;	//AD1.4
        AD1CR |= 0x01000000;//start conversion
        
        while ((temp & 0x80000000) == 0)
        {
                temp = AD1DR;
        }
        
        
        temp &= 0x0000FFC0;
        temp2 = temp / 0x00000040;
        
        AD1CR = 0x00000000;
        
        printf("%d",temp2);
        put_char(9);
            
        //Get AD1.3=======================================================================
        AD1CR = 0x0020FF08;	//AD1.3
        AD1CR |= 0x01000000;//start conversion
        
        while ((temp & 0x80000000) == 0)
        {
                temp = AD1DR;
        }
        
        
        temp &= 0x0000FFC0;
        temp2 = temp / 0x00000040;
        
        AD1CR = 0x00000000;
                
        printf("%d",temp2);
        put_char(9);
            
        //Get AD0.3=======================================================================
        AD0CR = 0x0020FF08;	//AD0.3
        AD0CR |= 0x01000000;//start conversion
        
        while ((temp & 0x80000000) == 0)
        {
                temp = AD0DR;
        }
        
        
        temp &= 0x0000FFC0;
        temp2 = temp / 0x00000040;
        
        AD0CR = 0x00000000;
                
        printf("%d",temp2);        
        put_char(9);
            
        //Get AD0.2=======================================================================
        AD0CR = 0x0020FF04;	//AD0.2
        AD0CR |= 0x01000000;//start conversion
        
        while ((temp & 0x80000000) == 0)
        {
                temp = AD0DR;
        }
        
        temp &= 0x0000FFC0;
        temp2 = temp / 0x00000040;
        
        AD0CR = 0x00000000;
                
        printf("%d",temp2);  
        put_char(9);
              
        //Get AD0.1=======================================================================
        AD0CR = 0x0020FF02;	//AD0.1
        AD0CR |= 0x01000000;//start conversion
        
        while ((temp & 0x80000000) == 0)
        {
                temp = AD0DR;
        }
        
        temp &= 0x0000FFC0;
        temp2 = temp / 0x00000040;
        
        AD0CR = 0x00000000;
    
        printf("%d",temp2);
        put_char(9);
                
            
        //Get AD1.2========================================================================
        AD1CR = 0x0020FF04;	//AD0.0, P0.27
        AD1CR |= 0x01000000;	//start conversion
        
        while ((temp & 0x80000000) == 0)
        {
                temp = AD1DR;
        }
        
        temp &= 0x0000FFC0;
        temp2 = temp / 0x00000040;
        
        AD1CR = 0x00000000;
                
        printf("%d",temp2);        
        put_char(9);
            
        //Get AD0.4=======================================================================
        AD0CR = 0x0020FF10;	//AD0.4
        AD0CR |= 0x01000000;//start conversion
        
        while ((temp & 0x80000000) == 0)
        {
                temp = AD0DR;
        }
        
        temp &= 0x0000FFC0;
        temp2 = temp / 0x00000040;
        
        AD0CR = 0x00000000;
                
        printf("%d",temp2);        
        put_char(9);
            
        //Get AD1.7=======================================================================
        AD1CR = 0x0020FF80;	//AD1.7
        AD1CR |= 0x01000000;//start conversion
        
        while ((temp & 0x80000000) == 0)
        {
                temp = AD1DR;
        }
        
        temp &= 0x0000FFC0;
        temp2 = temp / 0x00000040;
        
        AD1CR = 0x00000000;
    
        printf("%d",temp2);
        put_char(9);
                
        
            
        //Get AD1.6=======================================================================
        AD1CR = 0x0020FF40;	//AD1.6
        AD1CR |= 0x01000000;//start conversion
        
        while ((temp & 0x80000000) == 0)
        {
                temp = AD1DR;
        }
        
        temp &= 0x0000FFC0;
        temp2 = temp / 0x00000040;
        
        AD1CR = 0x00000000;
    
        printf("%d\r\n",temp2);
       
        for (j = 0; j < 800000; j++);
        put_char(10);
        put_char(13);
    }


    printf("\r\nTest Complete.\r\n",0);
    while(1);


}

