#include "C:\projects\pic\PIC18LF1220\PIC\a.h"


// 3 channel software PWM driver
// 
// timer0 - PWM period 
// timer1 - short time intervals
//	interval  IDutyInc - between duty increment in auto mode  	- 0.13 S
// timer3 - long time intervals
//  interval  IState - between state switching in auto mode 	- 5 S

void rand_duty(int &r, int &rN);

// using pins

// analog inputs 
// A0 - analog input 1
// A1 - analog input 2
// A2 - analog input 3
//
// controlled outputs
// B3
// B2
// A7
//
// !!!! test output !!!!
// A3/A6
//
// mode switch
// A4


//#define test_pin PIN_A3 
#define test_pin PIN_A6 

#define channel_A_pin PIN_B3
#define channel_B_pin PIN_B2 
#define channel_C_pin PIN_A7 

#define analog_A 0
#define analog_B 1
#define analog_C 2 

#define mode_switch_pin PIN_A4

// global variable 
// logic flag for test purpose
boolean k = 0;

// logic flag - time interval IDutyInc has passed
boolean fDutyInc = 0;
// logic flag - time interval of one PWM period has passed
boolean fPWMPeriod = 0;
// logic flag - long time interval has passed
boolean fLongPeriod = 0;
// logic flag - long time interval has passed
boolean fSwitchPeriod = 0;


//address of duty value in EEPROM
BYTE address_duty=0;

//duty values
int A_duty=80;
int B_duty=182;
int C_duty=61;
int A_dutyNew=32;
int B_dutyNew=64;
int C_dutyNew=128;

//current value of timer 0 (PWM period)
int pwm_tik = 0;
//current time value from timer
int current_time = 0;
int long_time = 0;
int state_time = 0;
//period is equal LONG_PERIOD * timer3 period 
#define LONG_PERIOD 38		//10 Sec	time period between duty switching
#define STATE_PERIOD 230	//60 Sec time period between state switching	

//timer preset value to control period of timer
int16 timer_preset = 0;

//states in auto mode 
// 0 - fading 
// 1 - fast switch
// 2 - slow switch
int state = 0;

// mode switch
// 0 - manual set of duty's value through ADC reading 
// 1 - auto 
boolean mode;


// PWM period
#int_RTCC //HIGH
void RTCC_isr()
{
	set_timer0(159);

	pwm_tik++;
	if(pwm_tik == 0)
	{
		output_high(channel_A_pin);
		output_high(channel_B_pin);
		output_high(channel_C_pin);
	}
	else
	{
		{

			if(pwm_tik >= A_duty)
			{
				output_low (channel_A_pin);
			}
			if(pwm_tik >= B_duty)
			{
				output_low (channel_B_pin);
			}
			if(pwm_tik >= C_duty)
			{
				output_low (channel_C_pin);
			}
		}
	}

//	if(k==0) {k=1; output_high (test_pin);}
//		else {k=0; output_low (test_pin);}


}

// timer1 - short time intervals between modifying of duty value
//

#int_TIMER1
void TIMER1_isr()
{
	fDutyInc = 1;
	set_timer1(timer_preset);
}

#int_TIMER3
void TIMER3_isr()
{
	fLongPeriod = 1;
	//check mode switch 
	if( input(mode_switch_pin)) 
	{
		mode = 1;
	}
	else
	{
		mode = 0;
	}


	state_time++;
	long_time++;

	if(long_time == LONG_PERIOD)
	{
		long_time = 0;
		fSwitchPeriod = 1;
	}

	if(state_time == STATE_PERIOD)
	{
		state_time = 0;



		switch(state) {
			case 0:
				state = 1;
			break;
			case 1:
				state = 0;
			break;
		}




//		if(k==0) {k=1; output_high (test_pin);}
//		else {k=0; output_low (test_pin);}
	}
}


void main()
{

  	byte valueA;
  	byte valueB;
  	byte valueC;



	int16 l_value;


    setup_oscillator(OSC_8MHZ); 
//	setup_adc(ADC_OFF);
   	setup_adc(ADC_CLOCK_INTERNAL|ADC_TAD_MUL_0);
	setup_adc_ports(sAN0|sAN1|sAN2|VSS_VDD);

   	setup_wdt(WDT_OFF);
	setup_ccp1(CCP_OFF);
	
	//timer0 - PMW period
	//timer0 is configured as an 8-bit timer/counter
	//period = Tosc * 4 * Prescaler * 256 = 0.125 uS * 4 * 64 * 256 = 8.192mS
	//PWM frequency - 122Hz
//	setup_timer_0(RTCC_INTERNAL|RTCC_DIV_64|RTCC_8_BIT); 
	setup_timer_0(RTCC_INTERNAL|RTCC_DIV_1|RTCC_8_BIT); 
	set_timer0(159);		//period 48	uS, 48uS * 256 = 12.288 mS
 


 	//setup_timer_1(T1_DISABLED);

	//timer1 short time intervals
	//period = Tosc * 4 * Prescaler * 65536 = 0.125 uS * 4 * 4 * 65536 = 0.1310172S
	setup_timer_1 ( T1_INTERNAL | T1_DIV_BY_4 );

	//timer1 long time intervals
	//period = Tosc * 4 * Prescaler * 65536 = 0.125 uS * 4 * 8 * 65536 = 0.262144S
	setup_timer_3 ( T1_INTERNAL | T1_DIV_BY_8 );

   	setup_timer_2(T2_DISABLED,0,1);
//	setup_timer_2(T2_DIV_BY_16, 255, 16);
 //  	setup_timer_3(T3_DISABLED|T3_DIV_BY_1);
   	//setup_oscillator(OSC_8MHZ|OSC_NORMAL);

	enable_interrupts(INT_TIMER1);
	enable_interrupts(INT_TIMER3);

	enable_interrupts(INT_TIMER0);
	enable_interrupts(GLOBAL);


	valueA = read_EEPROM(address_duty); 
	if(valueA !=0) 
	{
		A_duty = valueA; 
		rand_duty(A_duty,A_dutyNew);
	}
	valueB = read_EEPROM(address_duty+1); 
	if(valueB !=0) 
	{
		B_duty = valueB;	
		rand_duty(B_duty,B_dutyNew);
	}
 	valueC = read_EEPROM(address_duty+2); 
	if(valueC !=0) 
	{
		C_duty = valueC;
		rand_duty(C_duty,C_dutyNew);
	}



   	while (TRUE) {
  	

		if(fLongPeriod)
		{
			fLongPeriod = 0;
			//manual mode
			//read ADC inputs and modify duty values
			if(!mode)
			{

				set_adc_channel( analog_A );
				delay_us(20);
				A_duty = read_adc();
				
				//duty value cannot be equal 0 because random generator will return 0
				if(!A_duty)
				{
					A_duty = 1;	
				}
				write_EEPROM(address_duty,A_duty);			

				set_adc_channel( analog_B );
				delay_us(20);
				B_duty = read_adc();
				if(!B_duty)
				{
					B_duty = 1;	
				}
				write_EEPROM(address_duty+1,B_duty);			

				set_adc_channel( analog_C );
				delay_us(20);
				C_duty = read_adc();
				if(!C_duty)
				{
					C_duty = 1;	
				}
				write_EEPROM(address_duty+2,C_duty);			
			}
		}



		//1 - auto mode
		if(mode)
		{
			switch(state) {
				//fading
				case 0:
			
					if(fDutyInc) 		//time to change duty value
					{
						fDutyInc = 0;	

						if(A_duty != A_dutyNew) {
							if(A_duty<A_dutyNew) A_duty++;
							else A_duty--;
						}
						else
						{
							rand_duty(A_duty,A_dutyNew);
							write_EEPROM(address_duty,A_dutyNew);			
						}

						if(B_duty != B_dutyNew) {
							if(B_duty<B_dutyNew) B_duty++;
							else B_duty--;
						}
						else
						{
							rand_duty(B_duty,B_dutyNew);
							write_EEPROM(address_duty+1,B_dutyNew);			
						}


						if(C_duty != C_dutyNew) {
							if(C_duty<C_dutyNew) C_duty++;
							else C_duty--;
						}
						else
						{
							rand_duty(C_duty,C_dutyNew);
							write_EEPROM(address_duty+2,C_dutyNew);			
						}

					}
				break;
				//fast switch
				case 1:
					if(fSwitchPeriod)
					{
						fSwitchPeriod = 0;
						rand_duty(A_duty,A_dutyNew);
						write_EEPROM(address_duty,A_dutyNew);
						A_duty = A_dutyNew;

						rand_duty(B_duty,B_dutyNew);
						write_EEPROM(address_duty+1,B_dutyNew);
						B_duty = B_dutyNew;

						rand_duty(C_duty,C_dutyNew);
						write_EEPROM(address_duty+2,C_dutyNew);
						C_duty = C_dutyNew;
					}
				break;
			
				case 2:
				break;
			}	//end of switch
		}
		else
		//0 - manual mode
		{
		}
		





   }
}


void rand_duty(int &r, int &rN){
	//value cannot be equal 0 !!!
	if(!r) r = 1;
	rN = r;
//	shift_right(&rN,1,(bit_test(r,2)^bit_test(r,0)));


	//omit duty values less than 64 (motor will not spin)
	do
	{
		shift_right(&rN,1,(bit_test(rN,2)^bit_test(rN,0)));
	}	while (rN<=64);
}
