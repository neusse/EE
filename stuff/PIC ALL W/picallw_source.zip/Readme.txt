You can get the password for PICALLW018.ZIP by making small donation (5 EUR)
for the software on www.picallw.com using PayPal. After receiving donation
you will get the unlock code per email in max 48 hours.

You can use the source or parts as you wish under 2 conditions:
1. Please do not publish the source code without my agreement
2. When publishing the compiled and modified Files please include in about box 
   based on PICALLW by Bojan Dobaj, Slovenia

best wishes,

Bojan Dobaj, Slovenia
picallw@gmx.net
