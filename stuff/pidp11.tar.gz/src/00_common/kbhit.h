/*
 * kbhit.h
 *
 *  Created on: 04.01.2012
 *      Author: joerg
 */

#ifndef KBHIT_H_
#define KBHIT_H_

//void reset_terminal_mode(void) ;
//void set_conio_terminal_mode(void) ;
int os_kbhit(void) ;

#endif /* KBHIT_H_ */
