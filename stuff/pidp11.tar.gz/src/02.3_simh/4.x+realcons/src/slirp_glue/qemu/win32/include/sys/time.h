#ifndef SYS_TIME_H
#define SYS_TIME_H

#include <time.h>

#endif
