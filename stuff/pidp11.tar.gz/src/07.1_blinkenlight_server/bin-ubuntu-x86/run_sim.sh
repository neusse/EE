#!/bin/sh

# ./blinkenlightd -c ~/beaglebone/panels/pdp11-40/pdp11-40.conf -s
# ./blinkenlightd -c ~/retrocmp/blinkenbone/panels/pdp10-ki10/pdp10-ki10.conf -s
 ./blinkenlightd -c ~/retrocmp/blinkenbone/panels/pdp11-70/pdp11-70.conf -s
