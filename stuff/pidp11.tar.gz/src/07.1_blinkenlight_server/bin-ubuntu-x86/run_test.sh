#!/bin/sh

./blinkenlightd -c ~/retrocmp/blinkenbone/panels/pdp11-70/pdp11-70.conf -t
# ./blinkenlightd -c ~/beaglebone/panels/ki10/pdp10-ki10.conf -t
# ./blinkenlightd -c ~/beaglebone/panels/pdp11-40/pdp11-40.conf -t
# ./blinkenlightd -c ~/beaglebone/projects/07.1_blinkenlight_server/panel_config_grammar/test.conf -t

