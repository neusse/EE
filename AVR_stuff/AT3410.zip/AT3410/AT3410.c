#include <mega16.h>
        
#define  MA	PORTA.4
#define  MC	PORTA.5
#define  puerta PORTA.6
#define  LUZ    PORTA.7
#define  PINTX	PIND.2
#define  LA	PINA.2
#define  LC	PINA.1
#define  OBJ	PINA.3
#define normal  0
#define cruzada 1
#define Pnl_On    1
#define Pnl_Off   0
#define  time_protect  1830             //30 segundos a 16 MHZ
#define  uno    1		                         
#define  cero   0 		
#define  CHANGE_TIME 100
#define  CINCO_SEC 300
#define parado   0
#define abriendo 1
#define cerrando 2
#define trancado 3
#define Si_Cero uno

            

bit FLAG_TX=0;

void para(void);			// Stop Routine
void abre(void);                        // Open routine
void cierra(void);                      // Close Routine
void Toogle_Door(void);                 //
void Save_Time(void);                   //
void Restore_Time(void);                //

unsigned long int TIEMPO=0;
unsigned long int k=0;
unsigned long int Temp_Time=0;
int Estado =  0;  

bit Flag_Peatonal = Pnl_Off;
bit Flag_Celda= normal;              //Identifica si paso Obstaculo por la Fotocelda
int Luz_Time=0;
int Tiempo_Celda=0;                               
int Tiempo_Peatonal=0;


// External Interrupt 0 service routine
interrupt [EXT_INT0] void ext_int0_isr(void)
{  

TCNT0=0;
while(TCNT0<255);
if (PINTX==uno)

{

k=0;                    
FLAG_TX=1;
}

}

// Timer 0 overflow interrupt service routine
interrupt [TIM0_OVF] void timer0_ovf_isr(void)
{
TIEMPO++;           
k++;  
Tiempo_Celda++; 
Tiempo_Peatonal++;

    if ((Estado==abriendo)||(Estado==cerrando))
      
	{       
	   	    {
	       	Luz_Time++;    
			if (Luz_Time==30)
			{
				if (LUZ==0)
				LUZ=1;
				else
				LUZ=0;
				Luz_Time=0;
			}
             }
           
	}    

	else
		   LUZ=cero;                   

}

void main(void)
{
// Declare your local variables here
// Input/Output Ports initialization
// Port A initialization
// Func7=Out Func6=Out Func5=Out Func4=Out Func3=In Func2=In Func1=In Func0=In
// State7=0 State6=0 State5=0 State4=0 State3=T State2=T State1=T State0=T
PORTA=0x00;
DDRA=0xF0;

// Port B initialization
// Func7=In Func6=In Func5=In Func4=In Func3=In Func2=In Func1=In Func0=In
// State7=T State6=T State5=T State4=T State3=T State2=T State1=T State0=T
PORTB=0x00;
DDRB=0x00;

// Timer/Counter 0 initialization
// Clock source: System Clock
// Clock value: 15.625 kHz
TCCR0=0x05;
TCNT0=0x00;

// Timer/Counter 1 initialization
// Clock source: System Clock
// Clock value: Timer 1 Stopped
// Mode: Normal top=FFFFh
// OC1A output: Discon.
// OC1B output: Discon.
// Noise Canceler: Off
// Input Capture on Falling Edge
TCCR1A=0x00;
TCCR1B=0x00;
TCNT1H=0x00;
TCNT1L=0x00;
OCR1AH=0x00;
OCR1AL=0x00;
OCR1BH=0x00;
OCR1BL=0x00;

// Timer/Counter 2 initialization
// Clock source: System Clock
// Clock value: Timer 2 Stopped
// Mode: Normal top=FFh
// OC2 output: Disconnected
ASSR=0x00;
TCCR2=0x00;
TCNT2=0x00;
OCR2=0x00;

// External Interrupt(s) initialization
// INT0: On
// INT0 Mode: Rising Edge
// INT1: Off
// INT2: Off
GICR|=0x20;
MCUCR=0x00;
MCUCSR=0x00;
GIFR=0x20;

// Timer(s)/Counter(s) Interrupt(s) initialization
TIMSK=0x01;

// Analog Comparator initialization
// Analog Comparator: Off
// Analog Comparator Input Capture by Timer/Counter 1: Off
// Analog Comparator Output: Off
ACSR=0x80;
SFIOR=0x00;
// Global enable interrupts

#asm("sei")
                 
                             
      MA=cero;
     MC=cero;
    puerta=cero;
    LUZ=cero;        

         
while (1)
      {           
//--------------------------------------
//  BEGINNING 
//--------------------------------------
LOOP4:          para();    

LOOP41:         while(FLAG_TX==0);

                Toogle_Door();  
         	if (k>120) 
	        goto LOOP41;  
LOOP3: 	 	abre();  
                Flag_Celda=normal;
                Estado=abriendo;		       //Open
  	 	TIEMPO=0;                            
//--------------------------------------
// IT IS OPENING CHECH FOR THE TX
//--------------------------------------
LOOP1:          if (FLAG_TX==1)
{                Toogle_Door();    
                if (Estado==parado)
                goto To_Close;                  
   		if (k>120)
	        goto LOOP1;
               	para();                //para si activa TX

        	FLAG_TX=0;
               	TIEMPO=0;
TOOGLE1:                                //SI FUE PEATONAL KEEP CHECKING         	
		while(FLAG_TX==0);       	
		Toogle_Door();
   		if (k>120)
	        goto TOOGLE1;
        	goto LOOP2;            // a cerrar
}                 
//--------------------------------------
//IT IS OPENING CHECH PHOTOCELL
//--------------------------------------
            	if (Flag_Celda==normal)
      {      	                   
               	if (OBJ==Si_Cero)  	
               	Flag_Celda=cruzada;    
               	Tiempo_Celda=0;
               	
      }     	
               else

  {      	if (OBJ==Si_Cero)
                 	Tiempo_Celda=0;
                 	else if (Tiempo_Celda>=120)
                 	{
                        goto From_Celda;
                 	}
     
  }     

//--------------------------------------
//IT IS OPENING CHECK LIMITS
//--------------------------------------
  		if (LA==Si_Cero)  
{  

From_Celda:                            
	   	para();		

To_Close:	   	        
	  	TIEMPO=0;
  	        while((TIEMPO<CINCO_SEC)&&(FLAG_TX==0))   //espera 5 segundos o que active el transmisors
{     	  	if (OBJ==Si_Cero)             // RESETEA EL TEIMPO CON LA FOTOCELDA
	  	TIEMPO=0;
}	  	FLAG_TX=0;              //limpia tx por si acaso		
	  	goto LOOP2;	  	// a cerrar
}       
//--------------------------------------
//IT OPENING CHECK TIME
//--------------------------------------
	        if (TIEMPO>=time_protect)
{   	 	para();

	 	TIEMPO=0;
	  	while((TIEMPO<CINCO_SEC)&&(FLAG_TX==0));   //espera 5 segundos o que active el transmisors
	  	FLAG_TX=0;              //limpia tx por si acaso		
	  	goto LOOP2;	  	// a cerrar
}	 	goto LOOP1;		// IMPORTANT !!			
//--------------------------------------
// START CLOSING DOOR
//--------------------------------------
LOOP2:		cierra();      
	        Estado=cerrando;
		TIEMPO=0;
LOOP5:		
//--------------------------------------
//IT IS CLOSING CHECK TX
//--------------------------------------
        	if (FLAG_TX==1)  
{ 	        Toogle_Door();
                if (Estado==parado)
                goto LOOP4;             
                if (Estado==trancado)
                goto To_CELDA;
               	if (k>120) 
                goto LOOP5;
                para();                //para si activa TX

        	FLAG_TX=0;
        	TIEMPO=0;
TOOGLE2:                                //SI FUE PEATONAL KEEP CHECKING         	
		while(FLAG_TX==0);       	
		Toogle_Door();
   		if (k>120)
	        goto TOOGLE2;
        	goto LOOP3;            // a ABRIR
	        }                                
//--------------------------------------
//IT IS CLOSING CHECK LIMIT
//--------------------------------------
          	if (LC==Si_Cero) 
{	        goto LOOP4;
	        }             
//--------------------------------------
// IT IS CLOSING CHECK PHOTOCELL
//--------------------------------------
            	if (OBJ==Si_Cero)  	
{		para();

        	TIEMPO=0;    
To_CELDA:      	while(TIEMPO<=CHANGE_TIME);     //espera 1 segundo para abrir 		 
                goto LOOP3;
		}
//--------------------------------------
//IT IS CLOSED 
//--------------------------------------
         if (TIEMPO>=time_protect)
        	{  
        	goto LOOP4;
        	}
//--------------------------------------
//KEEP CKECKING
//--------------------------------------
      		goto LOOP5;	 
		}}                  
//--------------------------------------
// FUNCION PARAR
//--------------------------------------
	void para(void)
		{   
		MA=cero;
		MC=cero;
		//LUZ=cero;
			        Estado=parado;
		}
//--------------------------------------
// FUNCION ABRIR
//--------------------------------------
	void abre(void)
		{       
		MA=uno;
		}
//--------------------------------------
// FUNCION CERRAR
//--------------------------------------
	void cierra(void)
		{          
		MC=uno;
		}                     
//--------------------------------------
// FUNCION PUERTA PEATONAL
//--------------------------------------
	void Toogle_Door(void)
		{  
		Save_Time();
	        FLAG_TX=0;        	       //limpia flag
	        Tiempo_Peatonal=0;
	DOOR1:	
	       if (k>120)  
{		
               if (Flag_Peatonal==Pnl_Off)
                {
                puerta=uno;     
                Tiempo_Peatonal=0;
                Flag_Peatonal=Pnl_On;
                }
               
               else  if (Tiempo_Peatonal>60)
               {
               puerta=cero;    
               
                }
               
}	        
                
               
                if (PINTX==uno)
               
{               
                         if (Estado==parado)
                    {    		goto DOOR1;                
				}               


		else
{              
                            if (Estado==abriendo)
			{  
			
			    if  (LA==Si_Cero)
			    {        para();
			             
			              goto DOOR1;     
			     }           
			         
			         else
			         {       
	                  	if (Flag_Celda==normal)
      	      			{      	                   
			               	if (OBJ==Si_Cero)  	
			               	Flag_Celda=cruzada;    
			               	Tiempo_Celda=0;
	               		}     	
			               else
	  			{      	
     				  if (OBJ==Si_Cero)
                 			Tiempo_Celda=0;
		                 	else if (Tiempo_Celda>=120)
                		 	{       
                		 	para();

               		 	}
			                
			          }      
			                
			}      }     


       if (Estado==cerrando)
            {       

                	if (LC==Si_Cero) 
        			{     
			       para();

		               	goto DOOR1;
                		}  		

  	
  		   if (OBJ==Si_Cero)  	
		   	      {               
		                para();

		               	goto DOOR1;
				} 

		} 


}

           goto DOOR1;   
}            


        	else
{	        puerta=cero;
                Flag_Peatonal=Pnl_Off;
}               Restore_Time();
}                          

//--------------------------------------
// FUNCION SALVAR TIEMPO
//--------------------------------------
	 void Save_Time(void)
		 {
		 Temp_Time=TIEMPO;
		 }                   
//--------------------------------------
// FUNCION RECUPERA TIEMPO
//--------------------------------------
	 void Restore_Time(void)
		 {
		 TIEMPO=Temp_Time;
		 }
                  






