tinybld_ds2010_20MHz__19200.hex			20MHz quartz => 5MIPS
tinybld_ds3013_int7.37MHz_115200alt.hex		internal.osc => 30MIPS, using alternate UART1
tinybld_ds4012_20MHz__19200.hex			20MHz quartz => 5MIPS
tinybld_ds6014_7.37MHz_115200uart2.hex		7.37MHz quartz => 30MIPS, using UART2
